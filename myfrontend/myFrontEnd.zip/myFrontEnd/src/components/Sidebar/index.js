import React from 'react';
import {
  SidebarContainer,
  Icon,
  CloseIcon,
  SidebarMenu,
  SidebarLink,
  SidebarRoute,
  SideBtnWrap
} from './SidebarElements';

const Sidebar = ({ isOpen, toggle }) => {
  return (
    <SidebarContainer className='Container' isOpen={isOpen} onClick={toggle}>
      <Icon onClick={toggle}>
        <CloseIcon />
      </Icon>
      <SidebarMenu>
        <SidebarLink to ='/'>Home</SidebarLink>
        <SidebarLink to='/'>Product</SidebarLink>
        <SidebarLink to='/'>Contact</SidebarLink>
        <SidebarLink to='/'>About</SidebarLink>
      </SidebarMenu>
      <SideBtnWrap>
        <SidebarRoute to='/'>Login</SidebarRoute>
      </SideBtnWrap>
      <SideBtnWrap>
        <SidebarRoute to='/'>Register</SidebarRoute>
      </SideBtnWrap>
    </SidebarContainer>
  );
};

export default Sidebar;
import { get } from './callAPI';
import React,{ Component} from 'react';
import { withRouter } from 'react-router-dom';
import ViewDetail from './viewDetail';
class ProductDetail extends Component {
  constructor(props) {
    super(props);
    this.state ={
      productDetails:{}
    }
  }

  componentDidMount(){
    const productid = this.props.match.params.id;
   // console.log(this.props.match.params.id);
   
    get(`product/${productid}`).then(res=>{
     // console.log(res.data);
      this.setState({productDetails:res.data});
    }
    );
  }

  render() {
    return (
      <ViewDetail 
      image={this.state.productDetails.image}
      name={this.state.productDetails.name}
      price={this.state.productDetails.price}
      quantity={this.state.productDetails.quantity}
      describe={this.state.productDetails.describe}
      />
    )
  }

}

export default withRouter(ProductDetail);
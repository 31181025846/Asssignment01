import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import UserService from "../services/user.service";
import AddCategory from '../components/add-category.component'
import Category from '../components/category.component'
import CategoriesList from '../components/categories-list.component'
import "./board-admin.css"

export default class BoardAdmin extends Component {
  constructor(props) {
    super(props);

    this.state = {
      content: ""
    };
  }

  componentDidMount() {
    UserService.getAdminBoard().then(
      response => {
        this.setState({
          content: response.data
        });
      },
      error => {
        this.setState({
          content:
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString()
        });
      }
    );
  }

  render() {
    return (
      <div className="container">
        <header className="jumbotron">
        <div>
        <nav className="navbar navbar-expand navbar-dark bg-dark">
          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={"/admin/category/"} className="nav-link">
              Categories
              </Link>
            </li>
            <li className="nav-item">
              <Link to={"/admin/add"} className="nav-link">
                Add new
              </Link>
            </li>
          </div>
        </nav>

        <div className="container mt-3">
          <Switch>
            <Route exact path={["/admin/", "/admin/category/"]} component={CategoriesList} />
            <Route exact path="/admin/add" component={AddCategory} />
            <Route path="/admin/category/:id" component={Category} />
          </Switch>
        </div>
      </div>
        </header>
      </div>
    );
  }
}

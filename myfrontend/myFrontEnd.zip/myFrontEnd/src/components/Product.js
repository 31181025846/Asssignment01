import React, { Component } from "react";
import { get } from "./callAPI";
import "./product.css";
import {Link} from "react-router-dom"

export default class Product extends Component {
  constructor(props) {
    super(props);
    this.state = {
      products: [],
      searchTerm: "",
    };
  }

  componentDidMount() {
    let params={};
    if(this.props.categoryId)
    params['categoryId'] = this.props.categoryId;
    get("product/",params).then((res) => {
      if (res !== undefined)
        if (res.status === 200) {
          console.log(res.data);
          this.setState({
            products: res.data,
          });
        }
    });
  }


  render() {
    const { searchTerm, products } = this.state;
    return (
      <div className='search-container'>
        <div className='blank-container'>
        <div className='searchbar-container'>
        <select className='select'>
          <option value="All">All</option>
          <option value="category">Cafe</option>
          <option value="category">Rượu</option>
          <option value="category">Sinh tố</option>
          <option value="category">Nước ép</option>

          </select>
        <input
          type="text"
          className="form-control"
          placeholder="search"
          onChange={(event) => {
            this.setState({ searchTerm: event.target.value });
          }}
        />
        </div>
        <ul className="list-group">
          {products
            .filter((product) => {
              if (searchTerm === "") {
                return product;
              } else if (
                product.name.toLowerCase().includes(searchTerm.toLowerCase())
              ) {
                return product;
              }
            })
            .map((product, index) => (
              <div className="card-grid" key={index}>
                <div className="card-border-border-primary" key={index}>
                  <img
                    src={product.image}
                    className="card-image card-img-top "
                    alt="..."
                  />
                  <div className="card-body">
                    <h5 className="card-title">{product.name}</h5>
                    <p className="card-price"> {product.price}</p>
                    <p className="card-text">{product.describe}</p>

                    <Link to={"/product/"+product.id} className="btn btn-primary">
                      Xem chi tiết
                    </Link>
                  </div>
                </div>
              </div>
            ))}
        </ul>
        </div>
      </div>
    );
  }
}

import React, { Component } from 'react';

class ViewDetail extends Component {
    render() {
        return (
            <div className="mt-3 mb-3">
            <img className="d-block img-fluid" src={this.props.image} alt="..." />
            <h1>{this.props.name}</h1>
            <h5 className="mt-3 mb-3">{this.props.price}</h5><br/>
            <h5 className="mt-3 mb-3">{this.props.quantity}</h5><br/>
            <p className="mt-3 mb-3">{this.props.describe}</p>
          </div>
        );
    }
}

export default ViewDetail;

import React, { Component } from "react";
import CategoryDataService from "../services/category.service";
import { Link } from "react-router-dom";

export default class CategoriesList extends Component {
  constructor(props) {
    super(props);
    this.retrieveCategories = this.retrieveCategories.bind(this);
    this.refreshList = this.refreshList.bind(this);
    this.setActiveCategory = this.setActiveCategory.bind(this);

    this.state = {
      categories: [],
      currentCategory: null,
      currentIndex: -1,
      searchTerm: "",
    };
  }

  componentDidMount() {
    this.retrieveCategories();
  }


  retrieveCategories() {
    CategoryDataService.getAll()
      .then((response) => {
        this.setState({
          categories: response.data,
        });
        console.log(response.data);
      })
      .catch((e) => {
        console.log(e);
      });
  }

  refreshList() {
    this.retrieveCategories();
    this.setState({
      currentCategory: null,
      currentIndex: -1,
    });
  }

  setActiveCategory(category, index) {
    this.setState({
      currentCategory: category,
      currentIndex: index,
    });
  }


  render() {
    const {
      categories,
      currentCategory,
      currentIndex,
      searchTerm,
    } = this.state;

    return (
      <div className="list row">
        <div className="col-md-8">
          <div className="input-group mb-3">
            {/* Test search filter */}
            <input
              type="text"
              className="form-control"
              placeholder="search"
              onChange={(event) => {
                this.setState({ searchTerm: event.target.value });
              }}
            />
          </div>
        </div>
        <div className="col-md-6">
          <h4>Category List</h4>

          <ul className="list-group">
            {categories &&
              categories
                .filter((category) => {
                  if (searchTerm === "") {
                    return category;
                  } else if (
                    category.name
                      .toLowerCase()
                      .includes(searchTerm.toLowerCase())
                  ) {
                    return category;
                  }
                })
                .map((category, index) => (
                  <li
                    className={
                      "list-group-item " +
                      (index === currentIndex ? "active" : "")
                    }
                    onClick={() => this.setActiveCategory(category, index)}
                    key={index}
                  >
                    {category.name}
                  </li>
                ))}
          </ul>
        </div>
        <div className="col-md-6">
          {currentCategory ? (
            <div>
              <h4>Category</h4>
              <div>
                <label>
                  <strong>Name:</strong>
                </label>
                {currentCategory.name}
              </div>
              <div>
                <label>
                  <strong>Status:</strong>
                </label>
                {currentCategory.published ? "Published" : "Pending"}
              </div>
              <Link
                to={"/admin/category/" + currentCategory.id}
                className="badge badge-warning btn btn-warning"
              >
                Edit Cate
              </Link>
            </div>
          ) : (
            <div>
              <br />
              <p>Please click on a Category...</p>
            </div>
          )}
        </div>
      </div>
    );
  }
}

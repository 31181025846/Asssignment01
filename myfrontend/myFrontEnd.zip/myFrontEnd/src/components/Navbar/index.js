import React, { Component } from "react";
import { Link } from "react-router-dom";
import "./Navbar.css";

 class Navbar extends Component {

  render() {
    return (
      <>
        <nav className="navbar">
          <ul>
            <Link to="/home">
              <li>Home</li>
            </Link>
            <Link to="/product">
              <li>Product</li>
            </Link>
            <Link to="/contact">
              <li>Contact</li>
            </Link>
            <Link to="/about">
              <li>About</li>
            </Link>
            <Link to="/register">
              <li>Register</li>
            </Link>
            <Link to="/login">
              <li>Login</li>
            </Link>
          </ul>

          <input type="text" onChange={(e) => this.props.onSearchKey(e)} />

          <div className="nav-details">
            <p className="nav-username"> Minh KHoa </p>
          </div>
        </nav>
      </>
    );
  }
}
export default Navbar;

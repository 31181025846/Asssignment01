import http from "../http-commonCate";
import { post, put, del} from "../components/callAPI";
class CategoryDataService {
    getAll() {
      return http.get(`/category/`);
    }
  
    get(id) {
      return http.get(`/category/${id}`);
    }
  
    create(data) {
      return post(`category/`, data);
    }
  
    update(id, data) {
      return put(`category/${id}`, data);
    }
  
    delete(id) {
      return del(`/category/${id}`);
    }
    findByName(name){
      return http.get(`/category?name=${name}`);
    }

  }
  
  export default new CategoryDataService();